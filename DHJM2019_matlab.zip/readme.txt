Matlab files:



- geneqm_v3_rr.m : Master code, calls other .m files as needed.


- costsim_v3.m : Solves the model economy for a given wage and parameterization. Is called by geneqm_v3_rr.m repeatedly in search for market clearing wage.


- tauchen.m : Tauchen transition matrix code (called by costsim_v3.m). Note: this code is inherited from others.


- saveout_ge.m : Saves summary results from model scenarios (called by geneqm_v3_rr.m)

load('outfile_ge.mat')
outfile=[outfile;temp];
save('outfile_ge.mat','outfile');

csvwrite('outfile_ge.csv',outfile);

fprintf('\n')
fprintf('Saved to disk.\n')
fprintf('\n')
fprintf('\n')

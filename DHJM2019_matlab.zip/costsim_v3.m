function outvec = costsim_v3(benchbeta,sd_e,rho_z,gamma,lcup,lcdn,fc,w,p,noise)

global alpha beta
global Ne Nz
global tol
global Nfirms Nperiods Ntrash
global benchB1 benchB3 benchB4


% Parameter p governs output format - for panel data output p=1, for
% aggregate stats output only p=0.
% Note even with p=0 you will get aggregate output from the function.

%% State and choice spaces

[ln_z,tran]=tauchen(rho_z,sd_e,Nz);

% Grid with richer spacing at lower values

zlow=(w/(alpha*min(exp(ln_z))))^(1/(alpha-1));
zhi=(w/(alpha*max(exp(ln_z))))^(1/(alpha-1));
cape=(floor(zhi/20)+2)*20;

gcons=(cape/20)/log(3*Ne/4+1);
e_grid=zeros(1,Ne);
e_grid(1)=zlow;
for i=2:3*Ne/4
    e_grid(1,i)=gcons*log(Ne-i+2)-gcons*log(Ne-i+1)+e_grid(i-1);
end
%e_grid(Ne/2)=cape/4;

e_grid(3*Ne/4:Ne)=linspace(e_grid(3*Ne/4),cape,Ne/4+1);




%% Value function iteration

% Populate a profit block
fprintf('Value function iteration...\n')
fprintf('\n')
tic
profit=zeros(Ne,Ne,Nz);
for iz=1:Nz
    for ie=1:Ne
        
        %Upward adjustments
        profit(:,ie,iz)=exp(ln_z(iz))*e_grid(ie)^alpha-w*e_grid(ie)...
            -(gamma/2)*((e_grid(ie)-e_grid')./e_grid').^2.-fc;
        
        %Upward adjustments, e choice is geq previous e
        profit(1:ie,ie,iz)=profit(1:ie,ie,iz)-lcup*(abs(e_grid(ie)-e_grid(1:ie)'));
        
        %Downward adjustments, e choice is less than previous e
        profit(ie+1:end,ie,iz)=profit(ie+1:end,ie,iz)-lcdn*(abs(e_grid(ie)-e_grid(ie+1:end)'));
        
    end
end


Vprime=ones(Nz,Ne);




%VFI 
gap=100;
fprintf('gap=100');
ivfi=0;
while gap>tol;
    ivfi=ivfi+1;
    % Hiring arm
    EVprime=tran*Vprime;
    Vh=zeros(Ne,Nz);
    Ih=zeros(Ne,Nz);
    for iz=1:Nz
        
        [Vtemp Itemp]=max(profit(:,:,iz)+beta*repmat(EVprime(iz,:),Ne,1),[],2);
        Vh(:,iz)=Vtemp;
        Ih(:,iz)=Itemp;
    end
    
    Vh=Vh';
    Ih=Ih';
    
    % Inaction arm
    Vi=zeros(Nz,Ne);
    for iz=1:Nz
        Vi(iz,:)=exp(ln_z(iz))*e_grid.^alpha-w*e_grid+beta*EVprime(iz,:);
    end
    
    V=max(Vi,Vh);
    Ii=Vi>Vh;
    
    gap=max(abs(V(:)-Vprime(:)));
    if mod(ivfi,50)==0
        
        fprintf('...%s',gap)
    end
    if mod(ivfi,250)==0
        fprintf('\n')
    end
    
    
    
    Vprime=V;
    
end

%Build Employment policy rule
for iz=1:Nz
    for ie=1:Ne
        if Ii(iz,ie)==1
            Ih(iz,ie)=ie;
        end
    end
end


diff=Vh-Vprime;
fprintf('\n')
fprintf('VFI complete...')
toc
fprintf('\n')


clear Vprime EVprime Vh Vi profit V

%% Create panel of firms
%{
1. Draw N draws from uniform distribution on 0 1.
2. Bin them using the stationary distribution of z, assiging them z=1 to Nz.
3. Initialize every firm's employment
4. Iterate through time using policy function and transition probabilities
 -- for each t, give each firm a new uniform draw based on trans, bin them, give them new z. Also give them new E with policy functions.
%}
tic
fprintf('\n')
fprintf('Simulating panel of %d firms',Nfirms)
fprintf(' for %d periods...\n',Nperiods)
fprintf('\n')
fprintf('Firm 1')

sstran=tran^100;
sstran=sstran(1,:);
sstran_cumu=sstran;
tran_cumu=tran;
for iz=2:Nz
    sstran_cumu(iz)=sstran_cumu(iz-1)+sstran(iz);
    tran_cumu(:,iz)=tran_cumu(:,iz-1)+tran(:,iz);
end

rng(1,'twister');
initialz=rand(Nfirms,1);

%Begin populating firms

aggpos=zeros(Nperiods,1);
aggneg=zeros(Nperiods,1);
aggdenom=zeros(Nperiods,1);
avg_inaction=zeros(Nperiods,1);
avg_tfp=zeros(Nperiods,1);
avg_lp=zeros(Nperiods,1);
var_tfp=zeros(Nperiods,1);
var_lp=zeros(Nperiods,1);

aggemp=zeros(Nperiods,1);
aggtfp_wt=zeros(Nperiods,1);
agglp_wt=zeros(Nperiods,1);

agg_q=zeros(Nperiods,1);

rng(1,'twister');
tdraw=rand(Nperiods,Nfirms);

%Loop through every firm for its whole existence
for ifirm=1:Nfirms
    firmid=ifirm*ones(Nperiods,1);
    if mod(ifirm,200)==0
        fprintf('...%d',ifirm)
    end
    
    firmz(1,1)=min(find(sstran_cumu>initialz(ifirm)));
    firmemp(1,1)=5; %Arbitrary choice
    
    if noise==1 || noise==2 || noise==3
        eta=normrnd(1,0.033,[Nperiods,1]);
    else
        eta=ones(Nperiods,1);
    end
    
    if noise==2 || noise==3
        etalp=eta;
    else
        etalp=ones(Nperiods,1);
    end
    
    if noise==2
        eta=ones(Nperiods,1);
    end
    
   
    
    year(1,1)=1;
    firmgr(1,1)=0;
    firmgrnoise(1,1)=0;
    lfirmemp(1,1)=1;
    firmlp(1,1)=0;
    lagfirmlp(1,1)=0;
    lagln_z(1,1)=0;
    laginnov(1,1)=0;
    
    lp_preadjust(1,1)=0;
    

    for t=2:Nperiods
        year(t,1)=t;
        
        firmz(t,1)=min(find(tran_cumu(firmz(t-1),:)>tdraw(t,ifirm))); %Z transition
        firmemp(t,1)=Ih(firmz(t,1),firmemp(t-1,1)); %Emp policy function
        lfirmemp(t,1)=firmemp(t-1,1);
        firmgr(t,1)=(e_grid(firmemp(t,1))-e_grid(lfirmemp(t,1)))/(.5*(e_grid(lfirmemp(t,1))+e_grid(firmemp(t,1))));
        
        %Version with econometrician noise
        firmgrnoise(t,1)=(eta(t)*e_grid(firmemp(t,1))-eta(t-1)*e_grid(lfirmemp(t,1)))/(.5*(eta(t-1)*e_grid(lfirmemp(t,1))+eta(t)*e_grid(firmemp(t,1))));
        
        
                
        % Agg job flows
        if firmemp(t,1)>lfirmemp(t,1)
            aggpos(t,1)=aggpos(t,1)+e_grid(firmemp(t,1))-e_grid(lfirmemp(t,1));
        else
            aggneg(t,1)=aggneg(t,1)+e_grid(lfirmemp(t,1))-e_grid(firmemp(t,1));
        end
        aggdenom(t,1)=aggdenom(t,1)+(e_grid(firmemp(t,1))+e_grid(lfirmemp(t,1)))/2;
        
        tfp=ln_z(firmz(t,1));
        lagln_z(t,1)=ln_z(firmz(t-1,1));
        
        %Innovation
        laginnov(t,1)=lagln_z(t,1)-rho_z*lagln_z(t-1,1);
        
        %Output
        agg_q(t,1)=agg_q(t,1)+exp(tfp)*e_grid(firmemp(t,1))^alpha;
        
        %Inaction fraction
        if firmemp(t,1)==lfirmemp(t,1)
            inaction=1;
        else
            inaction=0;
        end
        %Recursive average
        lavg_inaction=avg_inaction(t,1);
        avg_inaction(t,1)=lavg_inaction+(inaction-lavg_inaction)/ifirm;
        
        
        %Productivity stats
        lp=log(exp(ln_z(firmz(t,1)))* ...
            e_grid(firmemp(t,1))^alpha/e_grid(firmemp(t,1)));
        firmlp(t,1)=lp;
        lagfirmlp(t,1)=log(exp(lagln_z(t,1))* ...
            e_grid(lfirmemp(t,1))^alpha/e_grid(lfirmemp(t,1)));
        
        
        lpnoise=log(exp(ln_z(firmz(t,1)))* ...
            e_grid(firmemp(t,1))^alpha/(etalp(t)*e_grid(firmemp(t,1))));
        firmlpnoise(t,1)=lpnoise;
              
        lagfirmlpnoise(t,1)=log(exp(lagln_z(t,1))* ...
            e_grid(lfirmemp(t,1))^alpha/(etalp(t-1)*e_grid(lfirmemp(t,1))));
        %In the above, revenue is measured correctly but employment in the
        %denominator is not (if noise infusion is turned on)
        
        lp_preadjust(t,1)=log(exp(ln_z(firmz(t, ...
            1)))*e_grid(lfirmemp(t,1))^alpha/e_grid(lfirmemp(t,1)));
        
        aggemp(t,1)=aggemp(t,1)+e_grid(firmemp(t,1));
        aggtfp_wt(t,1)=aggtfp_wt(t,1)+e_grid(firmemp(t,1))*ln_z(firmz(t,1));
        agglp_wt(t,1)=agglp_wt(t,1)+e_grid(firmemp(t,1))*lp;
        
        
        % Agg dispersion: generate means and std devs recursively
        lavg_tfp=avg_tfp(t,1);
        lavg_lp=avg_lp(t,1);
        
        avg_tfp(t,1)=lavg_tfp+(tfp-lavg_tfp)/ifirm;
        avg_lp(t,1)=lavg_lp+(lp-lavg_lp)/ifirm;
        
        var_tfp(t,1)=var_tfp(t,1)+lavg_tfp^2-avg_tfp(t,1)^2+(tfp^2-var_tfp(t,1)-lavg_tfp^2)/ifirm;
        var_lp(t,1)=var_lp(t,1)+lavg_lp^2-avg_lp(t,1)^2+(lp^2-var_lp(t,1)-lavg_lp^2)/ifirm;
        %Confirmed that these recursive methods get it right
        
       
        
    end
    
    temppanel=[firmgr ones(Nperiods,1) ln_z(firmz)' log(e_grid(lfirmemp)') e_grid(firmemp)' ...
        ones(Nperiods,1) firmlp log(e_grid(lfirmemp)') ...
        ones(Nperiods,1) lagln_z log(e_grid(lfirmemp)') ...
        ones(Nperiods,1) laginnov log(e_grid(lfirmemp)') ...
        ones(Nperiods,1) lagfirmlpnoise log(eta.*e_grid(lfirmemp)') ...
        firmid year firmgrnoise];
    
    if ifirm==1
        panel=temppanel(Ntrash+1:end,:);
    else
        panel=[panel;temppanel(Ntrash+1:end,:)];
    end
    
end
aggpos=aggpos(Ntrash+1:end,:);
aggneg=aggneg(Ntrash+1:end,:);
aggdenom=aggdenom(Ntrash+1:end,:);

sd_lp=sqrt(var_lp);

%% Noise for employment data
rng(1,'twister');
eta=normrnd(1,0.033,[Nfirms*Nperiods,1]);


%% OLS on firm panel

y=panel(:,1);

%Current growth on current TFP
X=panel(:,2:4);
B1=inv(X'*X)*X'*y;
resid=y-X*B1;
SSE=resid'*resid/(length(y)-2);
std_errors=SSE*inv(X'*X);

pr_emp1=X*B1.*exp(X(:,3))+exp(X(:,3));

%Save benchmark coefficient if applicable, otherwise apply benchmark to
%this panel
if benchbeta==1
    benchB1=B1;
    fprintf('\n')
    fprintf('Initializing betas')
    fprintf('\n')
end

pr_emp1_cf=X*benchB1.*exp(X(:,3))+exp(X(:,3));



%Current growth on current LP
X=panel(:,6:8);
B2=inv(X'*X)*X'*y;

%Current growth on lagged TFP
X=panel(:,9:11);
B3=inv(X'*X)*X'*y;

pr_emp3=X*B3.*exp(X(:,3))+exp(X(:,3));

if benchbeta==1
    benchB3=B3;
end

pr_emp3_cf=X*benchB3.*exp(X(:,3))+exp(X(:,3));



%Current growth on lagged TFP innovation
X=panel(:,12:14);
B4=inv(X'*X)*X'*y;

pr_emp4=X*B4.*exp(X(:,3))+exp(X(:,3));

if benchbeta==1
    benchB4=B4;
end

pr_emp4_cf=X*benchB4.*exp(X(:,3))+exp(X(:,3));



%Noise-infused current growth on lag tfp
y=panel(:,20);
X=panel(:,15:17);
B5=inv(X'*X)*X'*y;


%Add to panel
panel=[panel(:,1:19),pr_emp1,pr_emp3,pr_emp4,pr_emp1_cf,pr_emp3_cf,pr_emp4_cf panel(:,20)];


%% Build diff in diff counterfactuals based on linear policy function estimates

pr_aggp_wt=zeros(Nperiods,3);
pr_aggemp=zeros(Nperiods,3);
avgp=zeros(Nperiods,3);

pr_aggp_wt_cf=zeros(Nperiods,3);
pr_aggemp_cf=zeros(Nperiods,3);

fprintf('\n')
fprintf('Building counterfactual OP covariance for %d periods',Nperiods)
fprintf('\n')
fprintf('This may take some time...')
fprintf('\n')



for row=1:length(panel(:,1))
    
    t=panel(row,19);

    %Model-predicted agg prod
    pr_aggp_wt(t,:)=pr_aggp_wt(t,:)+[pr_emp1(row),pr_emp3(row),pr_emp4(row)].*[panel(row,3),panel(row,10),panel(row,13)];
    %column 3 is lnz, column 10 is lag lnz, column 13 is lag ln lp        
    pr_aggemp(t,:)=pr_aggemp(t,:)+[pr_emp1(row),pr_emp3(row),pr_emp4(row)];

    %Counterfactual low-cost predicted agg prod
    pr_aggp_wt_cf(t,:)=pr_aggp_wt_cf(t,:)+[pr_emp1_cf(row),pr_emp3_cf(row),pr_emp4_cf(row)].*[panel(row,3),panel(row,10),panel(row,13)];
    %column 3 is lnz, column 10 is lag lnz, column 13 is lag ln lp        
    pr_aggemp_cf(t,:)=pr_aggemp_cf(t,:)+[pr_emp1_cf(row),pr_emp3_cf(row),pr_emp4_cf(row)];

    %Avg prod
    avgp(t,:)=avgp(t,:)+(1/Nfirms)*[panel(row,3),panel(row,10),panel(row,13)];

end

pr_aggp=pr_aggp_wt(Ntrash+1:end,:)./pr_aggemp(Ntrash+1:end,:);
pr_aggp_cf=pr_aggp_wt_cf(Ntrash+1:end,:)./pr_aggemp_cf(Ntrash+1:end,:);


pr_cov=pr_aggp-avgp(Ntrash+1:end,:);
pr_cov_cf=pr_aggp_cf-avgp(Ntrash+1:end,:);
%Now you have the model-predicted weighted averages, this is a T by 3 vector.


    
pr_cov1=sum(pr_cov(:,1))/length(pr_cov(:,1));%Average the predicted wtf avg prod across years
pr_cov3=sum(pr_cov(:,2))/length(pr_cov(:,2));
pr_cov4=sum(pr_cov(:,3))/length(pr_cov(:,3));

pr_cov1_cf=sum(pr_cov_cf(:,1))/length(pr_cov(:,1));
pr_cov3_cf=sum(pr_cov_cf(:,2))/length(pr_cov(:,2));
pr_cov4_cf=sum(pr_cov_cf(:,3))/length(pr_cov(:,3));

%% Aggregate statistics

reallocation=(aggpos+aggneg)./aggdenom;
jc=aggpos./aggdenom;

agg_q_ces=agg_q.^(1/alpha);
%Note this is a vector over years

%% Save panel data if applicable

if p==1
    csvwrite('panel.csv',panel);
    fprintf('\n')
    fprintf('Panel data saved to disk.\n')
    fprintf('\n')
    fprintf('\n')
end


%% Calibration indicators

lpdisp=sum(sd_lp(Ntrash+1:end,1))/(Nperiods-Ntrash);
tfpdisp=sum(sqrt(var_tfp))/Nperiods;
inaction_share=sum(avg_inaction(Ntrash+1:end,1))/(Nperiods-Ntrash);

%Average size
%avgsize=sum(exp(panel(:,4)))/length(panel(:,4))/min(e_grid);
avgsize=sum(exp(panel(Ntrash+1:end,4)))/length(panel(Ntrash+1:end,4));

% Reallocation
rr=sum(reallocation)/length(reallocation);

%Top emp point
top=max(panel(:,5));

%Avg MPL, note will differ from unwt_avglp because MRP is not in logs
mrp=alpha*exp(panel(:,3)).*panel(:,5).^(alpha-1);
avg_mrp=sum(mrp(Ntrash+1:end,1))/length(mrp(Ntrash+1:end,1));

aggtfp=aggtfp_wt(Ntrash+1:end,1)./aggemp(Ntrash+1:end,1);
agglp=agglp_wt(Ntrash+1:end,1)./aggemp(Ntrash+1:end,1);

unwt_avglp=sum(avg_lp(Ntrash+1:end,1))/length(avg_lp(Ntrash+1:end,1));
unwt_avgtfp=sum(avg_tfp(Ntrash+1:end,1))/length(avg_tfp(Ntrash+1:end,1));

aggtfp=sum(aggtfp)/length(aggtfp);
agglp=sum(agglp)/length(agglp);

agg_q_avg=sum(agg_q(Ntrash+1:end,1))/length(agg_q(Ntrash+1:end,1));
agg_q_ces_avg=sum(agg_q_ces(Ntrash+1:end,1))/length(agg_q_ces(Ntrash+1:end,1));
aggemp_avg=sum(aggemp(Ntrash+1:end,1))/length(aggemp(Ntrash+1:end,1));


cov_tfp=aggtfp-unwt_avgtfp;
cov_lp=agglp-unwt_avglp;

%The below is fed to summary stat file for scenario
outvec=[lpdisp rr  ...
    B1(2) B2(2) B3(2) B4(2) B5(2) aggtfp agglp avg_mrp avgsize ...
    B1(3) B2(3) B3(3) B4(3) B5(3) top tfpdisp rho_z inaction_share ...
    sd_e unwt_avgtfp unwt_avglp cov_tfp cov_lp aggemp_avg agg_q_avg ...
    agg_q_ces_avg ...
    pr_cov1 pr_cov1_cf pr_cov3 pr_cov3_cf pr_cov4 pr_cov4_cf];

fprintf('\n')
fprintf('\n')
textbox=['gamma = ',num2str(gamma),'; lcup = ',num2str(lcup),'; lcdn = ',num2str(lcdn),'; fc = ',num2str(fc)];
disp(textbox)
fprintf('Simulation complete...')
toc
fprintf('\n')

end

%% Housekeeping

clear
clc

global alpha beta
global Ne Nz
global tol
global Nfirms Nperiods Ntrash

alpha=0.8;              % Decreasing returns to scale in production
beta=0.96;               % Discount factor

Ne=2400;                 % Number of points on employment grid, must be divisible by 4


Nz=115;                     % Number of points on TFP grid


tol=1.e-10;             %Value function iteration tolerance
eqmtol=0.0005;        %Labor market clearing tolerance


Nfirms=2000;             % Number of simulated firms


Nperiods=1000;          % Number of simulated periods


Ntrash=100;             % Number of initial periods to burn

p=1;                    % Panel data output. Set p=1 to have costsim save panel microdata. Else p=0.

%% Calibrations

% Note RR target is 0.25, the 1980s average of excess reallocation for
% manufacturing


rho_z=0.80; %RFRS target 0.80 from 1980s
sd_z=0.46; %RFRS target 0.46 from 1980s. Note
sd_e=sqrt(sd_z^2*(1-rho_z^2));
 
gamma=0;        %Quadratic adjustment cost. Is 0 in main baseline.
lcup=1.45;      %Upward kinked adjustment cost. 1.45 is consistent with RR=0.25 in baseline
lcdn=0;         %Downward kinked adjustment cost. Is 0 in baseline.
fc=0;           %Fixed cost. Not used.


outfile=zeros(1,40);                %Some housekeeping to save output
save('outfile_ge.mat','outfile');


%Noise infusion for measurement error
%noise=1 is emp only. noise=2 is prod only. noise=3 is emp and prod. anything else is
%no noise. In principle can build a loop to go through all possible values
%of this.
noise=4;


%% Scenario loops

% NOTE: currently, loop is set up for main adjustment cost/responsiveness
% experiments. That is, lcup is set at 1.45, and we will loop through
% values of lcdn.

% Alternatively, you can set up the loop to leave lcdn=0 and vary sd_z, the
% dispersion of TFP.

lcdvec=[0 0.25 0.5 0.75 1];     %Downward adj cost scenarios

for ild=1:length(lcdvec)  
    
    lcdn=lcdvec(ild);

    
    % Guess a wage, use bisection to clear the market based on average firm
    % size. Quicker if you already have a good idea of correct wage.
    
    
    if ild==1
        w=1.124;
        whi=1.13;
        wlo=1.12;
    elseif ild==2
        w=1.1054;
        whi=1.11;
        wlo=1.10;
    elseif ild==3
        w=1.092;
        whi=1.096;
        wlo=1.088;
    elseif ild==4
        w=1.0813;
        whi=1.085;
        wlo=1.077;
    else
        w=1.0737;
        whi=1.08;
        wlo=1.07;
    end
    
    
    
    lsupply=0.5282; % This is arbitrary. Fixes labor supply.
    
    laborgap=1; %Initializing
    
    if ild==1
        benchbeta=1;
        %Benchmark beta is the low-cost adjustment coefficient for
        %comparisons
    else
        benchbeta=0;
    end
    
    %Now clear the market
    while laborgap>eqmtol
        
        
        %Solve model for current wage guess
        temp=costsim_v3(benchbeta,sd_e,rho_z,gamma,lcup,lcdn,fc,w,p,noise);
        
        
        %Check market clearing
        laborgap=abs(log(lsupply)-log(temp(11)));
        %temp11 is average firm size (Aggregate labor demand divided by
        %Nfirms
        
        
        %Display progress
        fprintf('\n')
        fprintf('\n')
        textbox=['w = ',num2str(w),'; lcdn = ',num2str(lcdn),'; ex supply = ',num2str(log(lsupply)-log(temp(11))),'; fc = ',num2str(fc)];
        disp(textbox)
        
        
        %Update wage using bisection
        if laborgap>eqmtol
            if lsupply>temp(11)
                whi=w;
                w=w-.5*(w-wlo);
            else
                wlo=w;
                w=w+.5*(whi-w);
            end
        end
        
        
        
    end
    
    temp=[w gamma, lcup, lcdn, fc, temp, noise];
    
    
    %If p=1, will save panel data from model simulation. Need to rename the
    %file though
    if p==1
        if ild==1
            movefile('panel.csv','panel_ge_lcdn000.csv')
        elseif ild==2
            movefile('panel.csv','panel_ge_lcdn025.csv')
        elseif ild==3
            movefile('panel.csv','panel_ge_lcdn050.csv')
        elseif ild==4
            movefile('panel.csv','panel_ge_lcdn075.csv')
        elseif ild==5
            movefile('panel.csv','panel_ge_lcdn100.csv')
        else
            movefile('panel.csv','panel_ge_lcdn125.csv')
        end
    end
    
    %Saves outfile_ge.csv, with summary data for each scenario
    saveout_ge
    
end











